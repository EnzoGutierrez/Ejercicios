import random

def dados():
    a = random.randint(1,6)
    b = random.randint(1,6)
    c = random.randint(1,6)
    print('Los dados son:', a, ',', b, ',',c)
    return a, b, c

def suma_puntos(a,b,c,apuesta):
    puntos1 = 0
    division = (a + b + c) % 2
    if (division == 0 and apuesta == 1) or (division != 0 and apuesta == 2):
        puntos1 += max(a,b,c)
        print('Usted acerto su apuesta, se le suman', max(a,b,c), 'a su puntaje total\n')
    else:
        puntos1 -= min(a,b,c)
        print('Usted no acerto a su apuesta, se le resta el minimo', min(a,b,c), '\n')
    return puntos1

def paridad_en_todos(a,b,c,puntos1,apuesta):
    division = (a + b + c) % 2
    if (division == 0 and apuesta == 1) or (division != 0 and apuesta == 2):
        paridad_dado1 = a % 2
        paridad_dado2 = b % 2
        paridad_dado3 = c % 2
        if paridad_dado1 == 0 and paridad_dado2 == 0 and paridad_dado3 == 0:
            puntos1 *= 2
            print('Todos los dados son pares, por lo que se multiplica su puntaje\n')
        elif paridad_dado1 != 0 and paridad_dado2 != 0 and paridad_dado3 != 0:
            puntos1 *= 2
            print('Todos los dados son impares, por lo que se multiplica su puntaje\n')
        else:
            print('Obtuvo dados pares e impares, mantiene su puntaje igual\n')
    return puntos1
