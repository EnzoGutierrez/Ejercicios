import Libreria.Dados

def lanzamiento_dados(acu, acu_parcial,cont_aciertos):
    apuesta = int(input('Apueste si la suma de los dados de su proximo lazamiento sera par(1) o impar(2): '))
    input('Jugador presione enter para lanzar los dados')
    print()
    dado1, dado2, dado3 = Libreria.Dados.dados()
    puntos = Libreria.Dados.suma_puntos(dado1,dado2,dado3,apuesta)
    multi_puntos = Libreria.Dados.paridad_en_todos(dado1,dado2,dado3,puntos,apuesta)

    acu += multi_puntos
    acu_parcial += multi_puntos
    if acu_parcial > 0:
        cont_aciertos += 1

    return acu, acu_parcial,cont_aciertos

def resultados(acu1_parcial, acu2_parcial, rondas_ganadas1, ronda_ganada_seguidas1, rondas_ganadas2,
ronda_ganada_seguidas2,empate_ronda, jug1, jug2, acu1, acu2):
    print('RESULTADOS DE LA RONDA')
    if acu1_parcial > acu2_parcial:
        rondas_ganadas1 += 1
        ronda_ganada_seguidas1 += 1
        ronda_ganada_seguida2 = 0
        print('El ganador de la ronda es', jug1)
    elif acu2_parcial > acu1_parcial:
        rondas_ganadas2 += 1
        ronda_ganada_seguidas1 = 0
        ronda_ganada_seguidas2 += 1
        print('El ganador de la ronda es', jug2)
    else:
        empate_ronda = True
        ronda_ganada_seguidas1 = 0
        ronda_ganada_seguidas2 = 0
        print('Hubo un empate en esta ronda')
    
    print('El puntaje parcial del jugador 1 es de:', acu1)
    print('El puntaje parcial del jugador 2 es de:',acu2,'\n')
    return rondas_ganadas1, rondas_ganadas2, ronda_ganada_seguidas1, rondas_ganadas2, ronda_ganada_seguidas2, empate_ronda

def salida(a, b, c, d, jug1, jug2, acu1, acu2):
    print('\nRESULTADOS FINALES')
    if a > b:
        print('Gano', jug1,'con',acu1,'puntos totales')
    elif b > a:
        print('Gano', jug2,'con', acu2,'puntos totales')
    else:
        if c > d:
            print('Gano', jug1,"con por cantidad de rondas ganadas\n")
        elif d > c:
            print('Gano', jug2,"con por cantidad de rondas ganadas\n")
        else:
            print("Ambos jugadores tuvieron la misma cantidad de puntos y rondas ganas, es un empate\n")
