def promedio(a, b, total):
    prom1 = round(a / total, 2)
    prom2 = round(b / total, 2)
    return prom1, prom2

def porcentaje(a, b, total):
    porcentaje1 = round((a * 100) / total, 2)
    porcentaje2 = round((b * 100) / total, 2)
    return porcentaje1, porcentaje2