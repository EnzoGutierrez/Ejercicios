import Libreria.Jugadores
import Libreria.Estadisticas

def test():
    jug1 = input('Ingrese el nombre del primer jugador: ')
    jug2 = input('Ingrese el nombre del segundo jugador: ')
    objetivo = int(input('Ingrese el puntaje final(Mayor a 10): '))
    while objetivo < 11:
        print('ERROR. El Valor debe ser mayor de 10')
        objetivo = int(input('Ingrese el puntaje final(Mayor a 10): '))

    acu1 = 0
    acu2 = 0
    cont_total_rondas = 0

    acu1_parcial = 0
    acu2_parcial = 0

    rondas_ganadas1 = 0
    rondas_ganadas2 = 0

    empate_ronda = False

    cont_acierto1 = 0
    cont_acierto2 = 0

    ronda_ganada_seguidas1 = 0
    ronda_ganada_seguidas2 = 0
    tres_rondas = False

    prom_jug1 = 0
    prom_jug2 = 0

    print()
    while acu1 < objetivo and acu2 < objetivo:
        cont_total_rondas += 1
        print('Turno del jugador 1')
        acu1, acu1_parcial, cont_acierto1 = Libreria.Jugadores.lanzamiento_dados(acu1, acu1_parcial, cont_acierto1)

        print('Turno del jugador 2')
        acu2, acu2_parcial, cont_acierto2 = Libreria.Jugadores.lanzamiento_dados(acu2, acu2_parcial, cont_acierto2)

        #Resultados de la ronda
        Libreria.Jugadores.resultados(acu1_parcial, acu2_parcial, rondas_ganadas1,
        ronda_ganada_seguidas1, rondas_ganadas2, ronda_ganada_seguidas2,empate_ronda, jug1, jug2, acu1, acu2)

    #Salida
    Libreria.Jugadores.salida(acu1,acu2,rondas_ganadas1, rondas_ganadas2,jug1, jug2, acu1, acu2)

    #Estadisticas
    print("\nESTADISTICAS DE JUEGO")
    #Cantidad de rondas
    print('La cantidad de rondas fue de:', cont_total_rondas)
    #Empate en las rondas
    if empate_ronda:
        print('Hubo al menos una ronda empatada')

    #Puntaje promedio entre jugadores
    prom_jug1, prom_jug2 = Libreria.Estadisticas.promedio(acu1,acu2,cont_total_rondas,)
    print('El promedio de puntos de',jug1,'es', prom_jug1)
    print('El promedio de puntos de',jug2,'es', prom_jug2)

    #Porcentaje de aciertos
    porcentaje1, porcentaje2 = Libreria.Estadisticas.porcentaje(cont_acierto1, cont_acierto2, cont_total_rondas)
    print('El porcentaje de acierto de',jug1,'es',porcentaje1)
    print('El porcentaje de acierto de',jug2,'es',porcentaje2)

    #Ganador de tres rondas seguidas
    if tres_rondas:
        print('Uno de los jugadores gano tres rondas seguidas')

#script principal...
test()
